# BitBreak

**A Proof-of-Work Credit Clearing Layer Anchored to Bitcoin**

Author: Jared Soriente Chang  
License: MIT  
Status: Prototype / Research Framework  
Version: 0.1.0

---

## What is BitBreak

BitBreak is a parallel proof-of-work blockchain that tracks Bitcoin-denominated credit obligations. It enables high-frequency exchange of Bitcoin-denominated value without altering Bitcoin's consensus rules, monetary supply, or base layer security.

Bitcoin remains the settlement layer. BitBreak becomes the ledger of obligations.

## Core Design Goals

1. Preserve Bitcoin's fixed supply and monetary policy
2. Avoid changes to Bitcoin consensus rules
3. Maintain a UTXO-based accounting model
4. Enable permissionless participation
5. Provide cryptographic auditability against Bitcoin
6. Fail safely without impacting Bitcoin's security or validity

## Architecture Overview

```
bitcoin-core (settlement layer)
        |
        | SPV proofs / RPC interface
        |
bitbreak-node (credit layer)
    ├── chain/        — BitBreak chain management, block validation
    ├── consensus/    — Proof-of-work, difficulty adjustment, rules
    ├── wallet/       — UTXO management, dust intake, credit issuance
    ├── rpc/          — JSON-RPC interface
    ├── index/        — BitBreak price index integration
    └── net/          — P2P network layer
```

## BitBreak Index

The BitBreak Index is integrated into the node as a reference layer tracking:
- Bitcoin and Litecoin live prices
- Gold and silver reference prices
- Satoshi dust value in USD
- Inflation data across major fiat currencies

This provides real-time context for credit issuance and dust threshold calculations.

## Status

This repository is a prototype framework. Core data structures and interfaces are defined. Full Bitcoin Core integration requires C++ implementation and testnet deployment. Contributions welcome.

## Getting Started

```bash
git clone https://github.com/YOUR_USERNAME/bitbreak
cd bitbreak
npm install        # for index tools
python3 -m pytest  # run tests
```

## License

MIT License — Copyright (c) 2026 Jared Soriente Chang

See LICENSE file for full terms.
