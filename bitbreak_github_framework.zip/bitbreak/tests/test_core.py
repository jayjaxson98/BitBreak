"""
bitbreak/tests/test_core.py

Unit tests for BitBreak core modules.

Author: Jared Soriente Chang
License: MIT
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from include.types import (
    BitcoinAnchor, UTXO, UTXOType, BitBreakTransaction,
    TransactionType, CreditTier, WalletState,
    DUST_THRESHOLD_SATS, SPV_CONFIRMATION_DEPTH
)
from src.wallet.credit import CreditIssuance, CREDIT_RATES, RESERVE_RATES
from src.consensus.rules import BlockValidator, DifficultyAdjuster
from include.types import BitBreakBlock


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_anchor(sats: int, confirmations: int = SPV_CONFIRMATION_DEPTH) -> BitcoinAnchor:
    return BitcoinAnchor(
        txid="a" * 64,
        vout=0,
        amount_sats=sats,
        merkle_proof=["proof"],
        block_header="b" * 64,
        block_height=800000,
        confirmations=confirmations
    )


# ---------------------------------------------------------------------------
# Types tests
# ---------------------------------------------------------------------------

class TestBitcoinAnchor:

    def test_valid_anchor(self):
        anchor = make_anchor(1000)
        assert anchor.is_valid_spv() is True

    def test_insufficient_confirmations(self):
        anchor = make_anchor(1000, confirmations=2)
        assert anchor.is_valid_spv() is False

    def test_zero_amount_invalid(self):
        anchor = make_anchor(0)
        assert anchor.is_valid_spv() is False

    def test_credit_tier_micro(self):
        assert make_anchor(100).get_credit_tier() == CreditTier.MICRO

    def test_credit_tier_at_dust_threshold(self):
        assert make_anchor(546).get_credit_tier() == CreditTier.MICRO

    def test_credit_tier_small(self):
        assert make_anchor(1000).get_credit_tier() == CreditTier.SMALL

    def test_credit_tier_medium(self):
        assert make_anchor(5000).get_credit_tier() == CreditTier.MEDIUM

    def test_credit_tier_large(self):
        assert make_anchor(20000).get_credit_tier() == CreditTier.LARGE

    def test_credit_tier_whale(self):
        assert make_anchor(100000).get_credit_tier() == CreditTier.WHALE


class TestUTXO:

    def test_spendable(self):
        u = UTXO("id1", UTXOType.BITBREAK_CREDIT, 1000, "pubkey")
        assert u.is_spendable() is True

    def test_spent_not_spendable(self):
        u = UTXO("id1", UTXOType.BITBREAK_CREDIT, 1000, "pubkey", spent=True)
        assert u.is_spendable() is False

    def test_dust_detection(self):
        u = UTXO("id1", UTXOType.CONFIRMED_BITCOIN, DUST_THRESHOLD_SATS, "pubkey")
        assert u.is_dust() is True

    def test_above_dust(self):
        u = UTXO("id1", UTXOType.CONFIRMED_BITCOIN, DUST_THRESHOLD_SATS + 1, "pubkey")
        assert u.is_dust() is False


class TestWalletState:

    def test_total_credit(self):
        wallet = WalletState("pubkey")
        wallet.bitbreak_credit = [
            UTXO("1", UTXOType.BITBREAK_CREDIT, 1000, "pubkey"),
            UTXO("2", UTXOType.BITBREAK_CREDIT, 2000, "pubkey"),
        ]
        assert wallet.total_bbk_credit() == 3000

    def test_dust_utxos(self):
        wallet = WalletState("pubkey")
        wallet.confirmed_bitcoin = [
            UTXO("1", UTXOType.CONFIRMED_BITCOIN, 400, "pubkey"),
            UTXO("2", UTXOType.CONFIRMED_BITCOIN, 10000, "pubkey"),
            UTXO("3", UTXOType.CONFIRMED_BITCOIN, 546, "pubkey"),
        ]
        dust = wallet.dust_utxos()
        assert len(dust) == 2


# ---------------------------------------------------------------------------
# Credit issuance tests
# ---------------------------------------------------------------------------

class TestCreditIssuance:

    def setup_method(self):
        self.utxo_set = {}
        self.issuance = CreditIssuance(self.utxo_set)

    def test_dust_intake_produces_transaction(self):
        anchor = make_anchor(5000)
        tx = self.issuance.intake_dust(anchor, "owner_pubkey")
        assert tx is not None
        assert tx.tx_type == TransactionType.DUST_INTAKE

    def test_dust_intake_creates_three_utxos(self):
        anchor = make_anchor(5000)
        tx = self.issuance.intake_dust(anchor, "owner_pubkey")
        assert len(tx.outputs) == 3

    def test_credit_rate_medium_tier(self):
        anchor = make_anchor(5000)
        tx = self.issuance.intake_dust(anchor, "owner_pubkey")
        credit_utxos = [u for u in tx.outputs if u.utxo_type == UTXOType.BITBREAK_CREDIT and u.owner_pubkey != "CONSOLIDATION_RESERVE"]
        assert len(credit_utxos) == 1
        expected = int(5000 * CREDIT_RATES[CreditTier.MEDIUM])
        assert credit_utxos[0].amount_sats == expected

    def test_conservation_not_violated(self):
        anchor = make_anchor(5000)
        tx = self.issuance.intake_dust(anchor, "owner_pubkey")
        # Conservation applies to credit outputs only.
        # Anchor UTXO represents the incoming Bitcoin asset, not a credit output.
        credit_out = sum(
            u.amount_sats for u in tx.outputs
            if u.utxo_type == UTXOType.BITBREAK_CREDIT
        )
        assert credit_out <= anchor.amount_sats

    def test_invalid_anchor_returns_none(self):
        anchor = make_anchor(5000, confirmations=0)
        tx = self.issuance.intake_dust(anchor, "owner_pubkey")
        assert tx is None

    def test_credit_tier_info_structure(self):
        info = self.issuance.get_credit_tier_info(5000)
        assert "tier" in info
        assert "credit_rate" in info
        assert "reserve_rate" in info
        assert "settlement_window_days" in info
        assert info["credit_sats"] + info["reserve_sats"] <= 5000


# ---------------------------------------------------------------------------
# Consensus tests
# ---------------------------------------------------------------------------

class TestBlockValidator:

    def setup_method(self):
        self.utxo_set = {}
        self.validator = BlockValidator(self.utxo_set)

    def _make_block(self) -> BitBreakBlock:
        b = BitBreakBlock(
            height=1,
            prev_hash="0" * 64,
            merkle_root="",
            bitcoin_anchor_hash="c" * 64,
            nonce=0,
            bits=0x1e000000
        )
        b.merkle_root = self.validator._compute_merkle_root([])
        return b

    def test_missing_bitcoin_anchor_fails(self):
        b = self._make_block()
        b.bitcoin_anchor_hash = ""
        b.block_hash = b.compute_hash()
        valid, msg = self.validator._check_bitcoin_anchor(b)
        assert valid is False

    def test_valid_anchor_hash_passes(self):
        b = self._make_block()
        b.block_hash = b.compute_hash()
        valid, msg = self.validator._check_bitcoin_anchor(b)
        assert valid is True


class TestDifficultyAdjuster:

    def test_slow_blocks_increase_difficulty(self):
        adj = DifficultyAdjuster()
        target = 2016 * 600
        slow = target * 2
        new_bits = adj.compute_next_bits(0x1d00ffff, 0, slow)
        assert new_bits > 0x1d00ffff

    def test_fast_blocks_decrease_difficulty(self):
        adj = DifficultyAdjuster()
        target = 2016 * 600
        fast = target // 2
        new_bits = adj.compute_next_bits(0x1d00ffff, 0, fast)
        assert new_bits < 0x1d00ffff

    def test_clamp_max_adjustment(self):
        adj = DifficultyAdjuster()
        target = 2016 * 600
        very_slow = target * 10
        new_bits = adj.compute_next_bits(0x1d00ffff, 0, very_slow)
        assert new_bits <= 0x1d00ffff * 4


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
