"""
bitbreak/main.py

BitBreak node entry point.

Author: Jared Soriente Chang
License: MIT
Status: Prototype — not production ready

Usage:
    python main.py [--rpc-host 127.0.0.1] [--rpc-port 8333] [--btc-host 127.0.0.1] [--btc-port 8332]
"""

import argparse
import sys
import threading
import time

from src.rpc.server import BitBreakRPC
from src.index.price_index import PriceIndex
from src.wallet.credit import CreditIssuance
from src.chain.bitcoin_rpc import BitcoinRPC
from include.types import UTXO


BANNER = """
╔══════════════════════════════════════════════════════╗
║              B I T B R E A K   N O D E               ║
║   Proof-of-Work Credit Clearing Layer for Bitcoin    ║
║                                                      ║
║   Author : Jared Soriente Chang                      ║
║   Version: 0.1.0  (prototype)                        ║
║   License: MIT                                       ║
╚══════════════════════════════════════════════════════╝
"""


def parse_args():
    p = argparse.ArgumentParser(description="BitBreak node")
    p.add_argument("--rpc-host",  default="127.0.0.1")
    p.add_argument("--rpc-port",  type=int, default=8333)
    p.add_argument("--btc-host",  default="127.0.0.1")
    p.add_argument("--btc-port",  type=int, default=8332)
    p.add_argument("--btc-user",  default="user")
    p.add_argument("--btc-pass",  default="pass")
    p.add_argument("--index-only", action="store_true",
                   help="Run price index display only, skip Bitcoin Core connection")
    return p.parse_args()


def check_bitcoin_connection(btc: BitcoinRPC) -> bool:
    height = btc.get_block_count()
    if height is not None:
        print(f"  Bitcoin Core connected — chain height: {height}")
        return True
    print("  WARNING: Bitcoin Core not reachable.")
    print("  Start Bitcoin Core with -rpcuser and -rpcpassword to enable anchor verification.")
    return False


def print_index_summary(index: PriceIndex):
    summary = index.summary()
    prices = summary["prices"]
    print("\n--- BitBreak Price Index ---")
    print(f"  BTC:   ${prices['btc_usd']:,.2f}" if prices['btc_usd'] else "  BTC:   unavailable")
    print(f"  LTC:   ${prices['ltc_usd']:,.2f}" if prices['ltc_usd'] else "  LTC:   unavailable")
    print(f"  Gold:  ${prices['gold_usd']:,.2f}" if prices['gold_usd'] else "  Gold:  unavailable")
    print(f"  1 sat: ${prices['sat_usd']:.8f}" if prices['sat_usd'] else "  1 sat: unavailable")
    print(f"  Dust:  ${prices['dust_usd']:.6f} (546 sats)" if prices['dust_usd'] else "  Dust:  unavailable")
    print(f"  BTC dom: {prices['btc_dominance']}%" if prices['btc_dominance'] else "")

    print("\n--- Satoshi vs Inflation ---")
    for code, rec in summary["inflation"].items():
        sat_real = f"${rec['sat_real']:.9f}" if rec['sat_real'] else "—"
        print(f"  {rec['country']:12s} {rec['currency']}  CPI {rec['cpi']:.1f}%  real sat: {sat_real}")


def main():
    print(BANNER)
    args = parse_args()

    utxo_set = {}
    index = PriceIndex()

    print("[1/3] Fetching price index...")
    print_index_summary(index)

    if not args.index_only:
        print("\n[2/3] Connecting to Bitcoin Core...")
        btc = BitcoinRPC(args.btc_host, args.btc_port, args.btc_user, args.btc_pass)
        check_bitcoin_connection(btc)
    else:
        print("\n[2/3] Index-only mode — skipping Bitcoin Core.")

    print(f"\n[3/3] Starting BitBreak RPC server on {args.rpc_host}:{args.rpc_port}...")
    rpc = BitBreakRPC(utxo_set, host=args.rpc_host, port=args.rpc_port)

    rpc_thread = threading.Thread(target=rpc.start, daemon=True)
    rpc_thread.start()
    print(f"  RPC ready. Example: curl -d '{{\"method\":\"getnodeinfo\"}}' http://{args.rpc_host}:{args.rpc_port}")
    print(f"  Methods: getindexsummary | getdustthreshold | getcredittierinfo | getwalletinfo | getnodeinfo")
    print("\nBitBreak node running. Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(60)
            print_index_summary(index)
    except KeyboardInterrupt:
        print("\nShutting down BitBreak node.")
        sys.exit(0)


if __name__ == "__main__":
    main()
