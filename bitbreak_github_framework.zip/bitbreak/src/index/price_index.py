"""
bitbreak/src/index/price_index.py

BitBreak Price Index — integrated market data layer.

Author: Jared Soriente Chang
License: MIT
Status: Prototype

Provides real-time and reference price data for:
- Bitcoin and Litecoin (CoinGecko public API — no key required)
- Gold via PAXG proxy (CoinGecko)
- Silver reference price
- Satoshi dust value calculations
- Inflation data by fiat currency (World Bank public API — no key required)

This module is integrated into the BitBreak node to inform
credit issuance thresholds and dust consolidation timing.
"""

import requests
import time
from typing import Optional, Dict
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

COINGECKO_BASE    = "https://api.coingecko.com/api/v3"
WORLDBANK_BASE    = "https://api.worldbank.org/v2"
DUST_THRESHOLD    = 546          # satoshis
SATS_PER_BTC      = 100_000_000
SILVER_REF        = 32.40        # USD/oz — update manually or via paid API

INFLATION_COUNTRIES = {
    "US":  {"name": "USA",      "currency": "USD"},
    "XC":  {"name": "Eurozone", "currency": "EUR"},
    "GB":  {"name": "UK",       "currency": "GBP"},
    "JP":  {"name": "Japan",    "currency": "JPY"},
    "CN":  {"name": "China",    "currency": "CNY"},
    "IN":  {"name": "India",    "currency": "INR"},
    "BR":  {"name": "Brazil",   "currency": "BRL"},
    "RU":  {"name": "Russia",   "currency": "RUB"},
    "AU":  {"name": "Australia","currency": "AUD"},
    "CA":  {"name": "Canada",   "currency": "CAD"},
    "DE":  {"name": "Germany",  "currency": "EUR"},
    "ET":  {"name": "Ethiopia", "currency": "ETB"},
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class PriceSnapshot:
    btc_usd:      Optional[float] = None
    ltc_usd:      Optional[float] = None
    gold_usd:     Optional[float] = None   # PAXG proxy
    silver_usd:   float = SILVER_REF
    sat_usd:      Optional[float] = None
    dust_usd:     Optional[float] = None
    btc_dominance: Optional[float] = None
    timestamp:    int = 0

    def is_valid(self) -> bool:
        return self.btc_usd is not None and self.btc_usd > 0

    def sats_per_usd(self) -> Optional[float]:
        if self.btc_usd:
            return SATS_PER_BTC / self.btc_usd
        return None

    def usd_per_sat(self) -> Optional[float]:
        if self.btc_usd:
            return self.btc_usd / SATS_PER_BTC
        return None

    def dust_threshold_usd(self) -> Optional[float]:
        if self.btc_usd:
            return (DUST_THRESHOLD / SATS_PER_BTC) * self.btc_usd
        return None


@dataclass
class InflationRecord:
    country_code: str
    country_name: str
    currency:     str
    cpi_rate:     float           # Annual CPI %
    sat_nominal:  Optional[float] = None   # USD value of 1 sat
    sat_real:     Optional[float] = None   # Inflation-adjusted sat value
    dust_nominal: Optional[float] = None   # USD value of 546 sats


# ---------------------------------------------------------------------------
# Price fetcher
# ---------------------------------------------------------------------------

class PriceIndex:
    """
    Fetches and caches market prices for BitBreak index operations.
    Cache TTL: 60 seconds for prices, 86400 seconds for inflation.
    """

    def __init__(self):
        self._price_cache: Optional[PriceSnapshot] = None
        self._price_ts: float = 0
        self._inflation_cache: Dict[str, InflationRecord] = {}
        self._inflation_ts: float = 0
        self.PRICE_TTL     = 60
        self.INFLATION_TTL = 86400

    def get_prices(self) -> PriceSnapshot:
        if time.time() - self._price_ts < self.PRICE_TTL and self._price_cache:
            return self._price_cache
        snap = self._fetch_prices()
        self._price_cache = snap
        self._price_ts = time.time()
        return snap

    def get_inflation(self) -> Dict[str, InflationRecord]:
        if time.time() - self._inflation_ts < self.INFLATION_TTL and self._inflation_cache:
            return self._inflation_cache
        data = self._fetch_inflation()
        self._inflation_cache = data
        self._inflation_ts = time.time()
        return data

    def _fetch_prices(self) -> PriceSnapshot:
        snap = PriceSnapshot(timestamp=int(time.time()))
        try:
            r = requests.get(
                f"{COINGECKO_BASE}/simple/price",
                params={
                    "ids": "bitcoin,litecoin,pax-gold",
                    "vs_currencies": "usd",
                    "include_24hr_change": "true",
                    "include_market_cap": "true"
                },
                timeout=8
            )
            d = r.json()
            snap.btc_usd  = d.get("bitcoin",  {}).get("usd")
            snap.ltc_usd  = d.get("litecoin", {}).get("usd")
            snap.gold_usd = d.get("pax-gold", {}).get("usd")

            btc_mcap = d.get("bitcoin", {}).get("usd_market_cap", 0)
            if btc_mcap:
                snap.btc_dominance = round((btc_mcap / (btc_mcap / 0.55)) * 100, 1)

            if snap.btc_usd:
                snap.sat_usd  = snap.btc_usd / SATS_PER_BTC
                snap.dust_usd = snap.sat_usd * DUST_THRESHOLD

        except Exception:
            pass
        return snap

    def _fetch_inflation(self) -> Dict[str, InflationRecord]:
        prices = self.get_prices()
        records: Dict[str, InflationRecord] = {}

        # World Bank CPI indicator: FP.CPI.TOTL.ZG
        wb_codes = ";".join(INFLATION_COUNTRIES.keys())
        try:
            r = requests.get(
                f"{WORLDBANK_BASE}/country/{wb_codes}/indicator/FP.CPI.TOTL.ZG",
                params={"format": "json", "mrv": 1, "per_page": 100},
                timeout=10
            )
            data = r.json()
            # World Bank returns [metadata, data_array]
            if isinstance(data, list) and len(data) > 1:
                for entry in data[1]:
                    if entry and entry.get("value") is not None:
                        code = entry["country"]["id"]
                        meta = INFLATION_COUNTRIES.get(code)
                        if meta:
                            cpi = float(entry["value"])
                            sat_nom = prices.usd_per_sat() if prices.is_valid() else None
                            sat_real = (sat_nom / (1 + cpi / 100)) if sat_nom else None
                            dust_nom = (sat_nom * DUST_THRESHOLD) if sat_nom else None
                            records[code] = InflationRecord(
                                country_code=code,
                                country_name=meta["name"],
                                currency=meta["currency"],
                                cpi_rate=round(cpi, 2),
                                sat_nominal=sat_nom,
                                sat_real=sat_real,
                                dust_nominal=dust_nom
                            )
        except Exception:
            pass

        # Fallback: use hardcoded estimates if World Bank unavailable
        if not records:
            fallback_cpi = {
                "US":2.7,"XC":2.3,"GB":3.2,"JP":2.5,"CN":0.6,
                "IN":4.9,"BR":4.5,"RU":8.6,"AU":3.0,"CA":2.7,
                "DE":2.2,"ET":27.5
            }
            for code, meta in INFLATION_COUNTRIES.items():
                cpi = fallback_cpi.get(code, 3.0)
                sat_nom = prices.usd_per_sat() if prices.is_valid() else None
                sat_real = (sat_nom / (1 + cpi / 100)) if sat_nom else None
                records[code] = InflationRecord(
                    country_code=code,
                    country_name=meta["name"],
                    currency=meta["currency"],
                    cpi_rate=cpi,
                    sat_nominal=sat_nom,
                    sat_real=sat_real,
                    dust_nominal=(sat_nom * DUST_THRESHOLD) if sat_nom else None
                )

        return records

    def summary(self) -> dict:
        """
        Return a summary dict for RPC exposure and dashboard display.
        """
        prices = self.get_prices()
        inflation = self.get_inflation()
        return {
            "prices": {
                "btc_usd":       prices.btc_usd,
                "ltc_usd":       prices.ltc_usd,
                "gold_usd":      prices.gold_usd,
                "silver_usd":    prices.silver_usd,
                "sat_usd":       prices.usd_per_sat(),
                "dust_usd":      prices.dust_threshold_usd(),
                "btc_dominance": prices.btc_dominance,
                "timestamp":     prices.timestamp
            },
            "inflation": {
                code: {
                    "country":    rec.country_name,
                    "currency":   rec.currency,
                    "cpi":        rec.cpi_rate,
                    "sat_nominal": rec.sat_nominal,
                    "sat_real":   rec.sat_real,
                    "dust_nominal": rec.dust_nominal
                }
                for code, rec in inflation.items()
            }
        }
