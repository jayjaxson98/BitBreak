"""
bitbreak/src/net/peer.py

P2P network layer stub for BitBreak node.

Author: Jared Soriente Chang
License: MIT
Status: Stub — not implemented

PROTOTYPE NOTE:
Full P2P implementation requires:
- Custom message serialization protocol
- Peer discovery and connection management
- Block and transaction propagation
- Parallel validation choice signaling
  (nodes declare whether they validate BTC, BBK, or both)

This stub defines the interface contracts only.
"""

from typing import List, Optional, Callable
from include.types import BitBreakBlock, BitBreakTransaction
from dataclasses import dataclass


@dataclass
class Peer:
    host: str
    port: int
    validates_bitcoin: bool = True
    validates_bitbreak: bool = True
    connected: bool = False
    version: str = "0.1.0"


class PeerManager:
    """
    Manages connections to BitBreak peers.

    Parallel validation choice per whitepaper:
    Nodes and miners may independently choose to validate
    Bitcoin blocks, BitBreak blocks, or both.
    """

    def __init__(self):
        self.peers: List[Peer] = []
        self._block_handlers: List[Callable] = []
        self._tx_handlers: List[Callable] = []

    def add_peer(self, host: str, port: int) -> Peer:
        peer = Peer(host=host, port=port)
        self.peers.append(peer)
        return peer

    def broadcast_block(self, block: BitBreakBlock):
        """
        Broadcast a new BitBreak block to all connected peers.
        STUB: implement socket-based propagation.
        """
        for peer in self.peers:
            if peer.connected and peer.validates_bitbreak:
                pass  # TODO: serialize and send block

    def broadcast_transaction(self, tx: BitBreakTransaction):
        """
        Broadcast a transaction to connected peers.
        STUB: implement socket-based propagation.
        """
        for peer in self.peers:
            if peer.connected and peer.validates_bitbreak:
                pass  # TODO: serialize and send tx

    def on_block(self, handler: Callable):
        self._block_handlers.append(handler)

    def on_transaction(self, handler: Callable):
        self._tx_handlers.append(handler)

    def peer_count(self) -> int:
        return len([p for p in self.peers if p.connected])
