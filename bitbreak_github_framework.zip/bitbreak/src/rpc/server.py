"""
bitbreak/src/rpc/server.py

JSON-RPC interface for the BitBreak node.

Author: Jared Soriente Chang
License: MIT
Status: Prototype — not production ready
"""

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Callable, Dict, Any
from src.index.price_index import PriceIndex
from src.wallet.credit import CreditIssuance
from include.types import UTXO


class BitBreakRPCHandler(BaseHTTPRequestHandler):

    methods: Dict[str, Callable] = {}

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            req = json.loads(body)
            method = req.get("method", "")
            params = req.get("params", [])
            rid = req.get("id", 1)
            if method in self.methods:
                result = self.methods[method](*params)
                resp = {"jsonrpc": "2.0", "result": result, "id": rid}
            else:
                resp = {"jsonrpc": "2.0", "error": {"code": -32601, "message": f"Method not found: {method}"}, "id": rid}
        except Exception as e:
            resp = {"jsonrpc": "2.0", "error": {"code": -32603, "message": str(e)}, "id": 1}

        raw = json.dumps(resp).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(raw))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, format, *args):
        pass  # suppress default logging


class BitBreakRPC:
    """
    Exposes BitBreak node functionality via JSON-RPC.

    Available methods:
      getindexsummary       — price index and inflation data
      getdustthreshold      — current dust threshold in USD
      getcredittierinfo     — credit rate for a given satoshi amount
      getwalletinfo         — wallet UTXO summary
      getnodeinfo           — node version and status
    """

    def __init__(self, utxo_set: Dict[str, UTXO], host: str = "127.0.0.1", port: int = 8333):
        self.host = host
        self.port = port
        self.index = PriceIndex()
        self.credit = CreditIssuance(utxo_set)
        self.utxo_set = utxo_set

        BitBreakRPCHandler.methods = {
            "getindexsummary":    self._get_index_summary,
            "getdustthreshold":   self._get_dust_threshold,
            "getcredittierinfo":  self._get_credit_tier_info,
            "getwalletinfo":      self._get_wallet_info,
            "getnodeinfo":        self._get_node_info,
        }

    def start(self):
        server = HTTPServer((self.host, self.port), BitBreakRPCHandler)
        print(f"BitBreak RPC listening on {self.host}:{self.port}")
        server.serve_forever()

    def _get_index_summary(self) -> dict:
        return self.index.summary()

    def _get_dust_threshold(self) -> dict:
        prices = self.index.get_prices()
        return {
            "sats": 546,
            "usd": prices.dust_threshold_usd(),
            "sat_usd": prices.usd_per_sat(),
            "btc_usd": prices.btc_usd
        }

    def _get_credit_tier_info(self, sats: int) -> dict:
        return self.credit.get_credit_tier_info(int(sats))

    def _get_wallet_info(self) -> dict:
        total_credit = sum(
            u.amount_sats for u in self.utxo_set.values()
            if not u.spent and u.utxo_type.value == "bbk_credit"
        )
        total_anchors = sum(
            1 for u in self.utxo_set.values()
            if not u.spent and u.utxo_type.value == "btc_anchor"
        )
        return {
            "total_bbk_credit_sats": total_credit,
            "active_anchors": total_anchors,
            "utxo_count": len(self.utxo_set)
        }

    def _get_node_info(self) -> dict:
        return {
            "version": "0.1.0",
            "name": "BitBreak",
            "author": "Jared Soriente Chang",
            "license": "MIT",
            "status": "prototype",
            "layer": "Bitcoin Layer 1 credit clearing",
            "whitepaper": "BitBreak: A Proof-of-Work Credit Clearing Layer Anchored to Bitcoin"
        }
