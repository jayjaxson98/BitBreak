"""
bitbreak/src/wallet/credit.py

Dust intake and credit issuance logic.

Author: Jared Soriente Chang
License: MIT
Status: Prototype — not production ready
"""

from include.types import (
    UTXO, UTXOType, BitcoinAnchor, BitBreakTransaction,
    TransactionType, CreditTier, DUST_THRESHOLD_SATS
)
from typing import Optional, Dict
import hashlib
import time


CREDIT_RATES: Dict[CreditTier, float] = {
    CreditTier.MICRO:  0.70,
    CreditTier.SMALL:  0.78,
    CreditTier.MEDIUM: 0.85,
    CreditTier.LARGE:  0.91,
    CreditTier.WHALE:  0.96,
}

RESERVE_RATES: Dict[CreditTier, float] = {
    CreditTier.MICRO:  0.30,
    CreditTier.SMALL:  0.22,
    CreditTier.MEDIUM: 0.15,
    CreditTier.LARGE:  0.09,
    CreditTier.WHALE:  0.04,
}

SETTLEMENT_WINDOWS_DAYS: Dict[CreditTier, int] = {
    CreditTier.MICRO:  90,
    CreditTier.SMALL:  60,
    CreditTier.MEDIUM: 30,
    CreditTier.LARGE:  14,
    CreditTier.WHALE:  7,
}


class CreditIssuance:
    """
    Handles conversion of Bitcoin dust UTXOs into BitBreak credit.

    Five-phase consolidation cycle per whitepaper:
    1. Dust intake — register UTXO as Bitcoin anchor
    2. Credit issuance — issue BBK at tier rate, hold reserve
    3. Credit circulation — peer-to-peer off base layer
    4. Consolidation — batch during low-fee window
    5. Settlement — destroy credit on Bitcoin settlement
    """

    def __init__(self, utxo_set: Dict[str, UTXO]):
        self.utxo_set = utxo_set

    def intake_dust(
        self,
        anchor: BitcoinAnchor,
        owner_pubkey: str
    ) -> Optional[BitBreakTransaction]:
        """
        Register a dust UTXO as a Bitcoin anchor and issue BBK credit.
        Returns a dust intake transaction or None if anchor is invalid.
        """
        if not anchor.is_valid_spv():
            return None

        tier = anchor.get_credit_tier()
        credit_rate = CREDIT_RATES[tier]
        credit_sats = int(anchor.amount_sats * credit_rate)
        reserve_sats = anchor.amount_sats - credit_sats

        anchor_utxo = UTXO(
            utxo_id=self._make_utxo_id(anchor.txid, "anchor"),
            utxo_type=UTXOType.BITCOIN_ANCHOR,
            amount_sats=anchor.amount_sats,
            owner_pubkey=owner_pubkey,
            anchor=anchor
        )
        credit_utxo = UTXO(
            utxo_id=self._make_utxo_id(anchor.txid, "credit"),
            utxo_type=UTXOType.BITBREAK_CREDIT,
            amount_sats=credit_sats,
            owner_pubkey=owner_pubkey
        )
        reserve_utxo = UTXO(
            utxo_id=self._make_utxo_id(anchor.txid, "reserve"),
            utxo_type=UTXOType.BITBREAK_CREDIT,
            amount_sats=reserve_sats,
            owner_pubkey="CONSOLIDATION_RESERVE"
        )

        tx = BitBreakTransaction(
            tx_id=self._make_txid(anchor.txid),
            tx_type=TransactionType.DUST_INTAKE,
            inputs=[],
            outputs=[anchor_utxo, credit_utxo, reserve_utxo],
            anchor=anchor
        )

        self.utxo_set[anchor_utxo.utxo_id] = anchor_utxo
        self.utxo_set[credit_utxo.utxo_id] = credit_utxo
        self.utxo_set[reserve_utxo.utxo_id] = reserve_utxo

        return tx

    def settle_credit(
        self,
        credit_utxo_id: str,
        settlement_anchor: BitcoinAnchor
    ) -> Optional[BitBreakTransaction]:
        """
        Destroy BBK credit upon Bitcoin settlement.
        One-way dependency: BitBreak credit cannot outlive its backing.
        """
        utxo = self.utxo_set.get(credit_utxo_id)
        if utxo is None or utxo.utxo_type != UTXOType.BITBREAK_CREDIT:
            return None
        if not settlement_anchor.is_valid_spv():
            return None

        utxo.spent = True
        tx = BitBreakTransaction(
            tx_id=self._make_txid(credit_utxo_id + "settlement"),
            tx_type=TransactionType.SETTLEMENT,
            inputs=[credit_utxo_id],
            outputs=[],
            anchor=settlement_anchor
        )
        return tx

    def get_credit_tier_info(self, sats: int) -> dict:
        temp = BitcoinAnchor(
            txid="0" * 64, vout=0, amount_sats=sats,
            merkle_proof=[], block_header="", block_height=0,
            confirmations=SPV_CONFIRMATION_DEPTH
        )
        tier = temp.get_credit_tier()
        return {
            "tier": tier.value,
            "credit_rate": CREDIT_RATES[tier],
            "reserve_rate": RESERVE_RATES[tier],
            "credit_sats": int(sats * CREDIT_RATES[tier]),
            "reserve_sats": int(sats * RESERVE_RATES[tier]),
            "settlement_window_days": SETTLEMENT_WINDOWS_DAYS[tier]
        }

    def _make_utxo_id(self, txid: str, suffix: str) -> str:
        return hashlib.sha256(f"{txid}:{suffix}".encode()).hexdigest()

    def _make_txid(self, raw: str) -> str:
        return hashlib.sha256(
            hashlib.sha256(f"{raw}:{time.time()}".encode()).digest()
        ).hexdigest()


# Import needed for get_credit_tier_info
from include.types import SPV_CONFIRMATION_DEPTH
