"""
bitbreak/src/consensus/rules.py

Consensus rules for the BitBreak proof-of-work chain.

Author: Jared Soriente Chang
License: MIT
Status: Prototype — not production ready

Implements core validation logic for BitBreak blocks and transactions.
Full production deployment requires Bitcoin Core RPC integration and
extensive testnet validation before any mainnet consideration.
"""

from include.types import (
    BitBreakBlock, BitBreakTransaction, BitcoinAnchor,
    UTXO, UTXOType, TransactionType, SPV_CONFIRMATION_DEPTH
)
from typing import List, Optional, Dict
import hashlib
import time


# ---------------------------------------------------------------------------
# Consensus parameters
# ---------------------------------------------------------------------------

DIFFICULTY_ADJUSTMENT_INTERVAL = 2016   # Blocks between difficulty adjustments
TARGET_BLOCK_TIME_SECONDS = 600         # 10 minutes, mirrors Bitcoin
MAX_BLOCK_SIZE_BYTES = 1_000_000        # 1MB prototype limit
COINBASE_MATURITY = 100                 # Blocks before miner reward spendable
GENESIS_BLOCK_HASH = "0" * 64          # Placeholder genesis hash


# ---------------------------------------------------------------------------
# Block validation
# ---------------------------------------------------------------------------

class BlockValidator:
    """
    Validates BitBreak blocks against consensus rules.
    Each block must commit to a valid Bitcoin state via SPV anchor.
    """

    def __init__(self, utxo_set: Dict[str, UTXO]):
        self.utxo_set = utxo_set

    def validate_block(self, block: BitBreakBlock) -> tuple[bool, str]:
        """
        Full block validation pipeline.
        Returns (is_valid, error_message).
        """
        checks = [
            self._check_proof_of_work(block),
            self._check_bitcoin_anchor(block),
            self._check_transaction_count(block),
            self._check_merkle_root(block),
        ]
        for valid, msg in checks:
            if not valid:
                return False, msg

        for tx in block.transactions:
            valid, msg = self.validate_transaction(tx)
            if not valid:
                return False, f"invalid tx {tx.tx_id}: {msg}"

        return True, "ok"

    def _check_proof_of_work(self, block: BitBreakBlock) -> tuple[bool, str]:
        computed = block.compute_hash()
        if computed != block.block_hash:
            return False, "block hash mismatch"
        if not block.meets_difficulty():
            return False, "insufficient proof of work"
        return True, "ok"

    def _check_bitcoin_anchor(self, block: BitBreakBlock) -> tuple[bool, str]:
        """
        Every BitBreak block must reference a valid Bitcoin block header.
        PROTOTYPE: Full implementation calls Bitcoin Core RPC getblockheader
        to verify the anchor hash exists in the Bitcoin chain.
        """
        if not block.bitcoin_anchor_hash or len(block.bitcoin_anchor_hash) != 64:
            return False, "missing or invalid bitcoin anchor hash"
        # TODO: verify anchor_hash against Bitcoin Core via RPC
        return True, "ok"

    def _check_transaction_count(self, block: BitBreakBlock) -> tuple[bool, str]:
        if len(block.transactions) == 0:
            return False, "empty block"
        return True, "ok"

    def _check_merkle_root(self, block: BitBreakBlock) -> tuple[bool, str]:
        """
        Verify merkle root matches transactions in block.
        PROTOTYPE: simplified — production requires full merkle tree.
        """
        computed = self._compute_merkle_root(block.transactions)
        if computed != block.merkle_root:
            return False, "merkle root mismatch"
        return True, "ok"

    def _compute_merkle_root(self, txs: List[BitBreakTransaction]) -> str:
        if not txs:
            return "0" * 64
        hashes = [t.tx_id for t in txs]
        while len(hashes) > 1:
            if len(hashes) % 2 != 0:
                hashes.append(hashes[-1])
            hashes = [
                hashlib.sha256((hashes[i] + hashes[i+1]).encode()).hexdigest()
                for i in range(0, len(hashes), 2)
            ]
        return hashes[0]

    def validate_transaction(self, tx: BitBreakTransaction) -> tuple[bool, str]:
        """
        Validate a BitBreak transaction against conservation and type rules.
        """
        if tx.tx_type == TransactionType.ANCHOR_REGISTRATION:
            return self._validate_anchor_registration(tx)
        elif tx.tx_type == TransactionType.CREDIT_TRANSFER:
            return self._validate_credit_transfer(tx)
        elif tx.tx_type == TransactionType.SETTLEMENT:
            return self._validate_settlement(tx)
        elif tx.tx_type == TransactionType.DUST_INTAKE:
            return self._validate_dust_intake(tx)
        return False, "unknown transaction type"

    def _validate_anchor_registration(self, tx: BitBreakTransaction) -> tuple[bool, str]:
        if tx.anchor is None:
            return False, "anchor registration requires bitcoin anchor"
        if not tx.anchor.is_valid_spv():
            return False, "invalid SPV proof"
        return True, "ok"

    def _validate_credit_transfer(self, tx: BitBreakTransaction) -> tuple[bool, str]:
        input_utxos = [self.utxo_set[i] for i in tx.inputs if i in self.utxo_set]
        if len(input_utxos) != len(tx.inputs):
            return False, "one or more inputs not found in UTXO set"
        if not all(u.utxo_type == UTXOType.BITBREAK_CREDIT for u in input_utxos):
            return False, "credit transfer inputs must be BBK credit UTXOs"
        if not tx.validate_conservation(input_utxos):
            return False, "output value exceeds input value — conservation violated"
        return True, "ok"

    def _validate_settlement(self, tx: BitBreakTransaction) -> tuple[bool, str]:
        if tx.anchor is None:
            return False, "settlement requires bitcoin anchor proving on-chain settlement"
        if not tx.anchor.is_valid_spv():
            return False, "invalid SPV proof for settlement"
        if len(tx.outputs) != 0:
            return False, "settlement destroys credit — no outputs permitted"
        return True, "ok"

    def _validate_dust_intake(self, tx: BitBreakTransaction) -> tuple[bool, str]:
        if tx.anchor is None:
            return False, "dust intake requires bitcoin anchor"
        if tx.anchor.amount_sats > 500_000:
            return False, "amount exceeds dust intake threshold"
        if not tx.anchor.is_valid_spv():
            return False, "invalid SPV proof for dust intake"
        return True, "ok"


# ---------------------------------------------------------------------------
# Difficulty adjustment
# ---------------------------------------------------------------------------

class DifficultyAdjuster:
    """
    Adjusts proof-of-work difficulty every 2016 blocks.
    Mirrors Bitcoin's retarget algorithm.
    """

    def compute_next_bits(
        self,
        current_bits: int,
        first_block_time: int,
        last_block_time: int
    ) -> int:
        actual_time = last_block_time - first_block_time
        target_time = DIFFICULTY_ADJUSTMENT_INTERVAL * TARGET_BLOCK_TIME_SECONDS

        # Clamp to 4x adjustment limit (mirrors Bitcoin)
        actual_time = max(actual_time, target_time // 4)
        actual_time = min(actual_time, target_time * 4)

        # PROTOTYPE: simplified bits adjustment
        # Production requires full Bitcoin-compatible target computation
        ratio = actual_time / target_time
        new_bits = int(current_bits * ratio)
        return new_bits
