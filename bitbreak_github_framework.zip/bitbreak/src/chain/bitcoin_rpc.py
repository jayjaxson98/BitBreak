"""
bitbreak/src/chain/bitcoin_rpc.py

Interface to Bitcoin Core via JSON-RPC.

Author: Jared Soriente Chang
License: MIT
Status: Prototype — not production ready

BitBreak connects to a running Bitcoin Core node via RPC to:
- Verify SPV proofs against the Bitcoin chain
- Fetch block headers for anchor validation
- Monitor confirmation depth of anchored transactions

Requires Bitcoin Core running with RPC enabled:
  bitcoind -rpcuser=user -rpcpassword=pass -rpcport=8332
"""

import json
import requests
from typing import Optional, Dict, Any
from include.types import BitcoinAnchor, SPV_CONFIRMATION_DEPTH


class BitcoinRPC:
    """
    Minimal Bitcoin Core RPC client for BitBreak anchor verification.
    Only implements the calls BitBreak requires.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8332,
        user: str = "user",
        password: str = "pass"
    ):
        self.url = f"http://{host}:{port}"
        self.auth = (user, password)
        self.headers = {"content-type": "application/json"}

    def _call(self, method: str, params: list = []) -> Optional[Any]:
        payload = {
            "method": method,
            "params": params,
            "jsonrpc": "2.0",
            "id": 1
        }
        try:
            r = requests.post(
                self.url,
                data=json.dumps(payload),
                headers=self.headers,
                auth=self.auth,
                timeout=10
            )
            result = r.json()
            if result.get("error"):
                return None
            return result.get("result")
        except Exception:
            return None

    def get_block_header(self, block_hash: str) -> Optional[Dict]:
        """Fetch a Bitcoin block header by hash."""
        return self._call("getblockheader", [block_hash, True])

    def get_transaction(self, txid: str) -> Optional[Dict]:
        """Fetch a raw Bitcoin transaction."""
        return self._call("getrawtransaction", [txid, True])

    def get_block_count(self) -> Optional[int]:
        """Get current Bitcoin chain height."""
        return self._call("getblockcount")

    def verify_anchor(self, anchor: BitcoinAnchor) -> bool:
        """
        Verify a BitcoinAnchor against the live Bitcoin chain.
        Checks:
        1. Transaction exists on chain
        2. Output index is valid
        3. Amount matches
        4. Confirmation depth meets minimum
        """
        tx = self.get_transaction(anchor.txid)
        if tx is None:
            return False

        vouts = tx.get("vout", [])
        if anchor.vout >= len(vouts):
            return False

        output = vouts[anchor.vout]
        on_chain_sats = int(round(output.get("value", 0) * 1e8))
        if on_chain_sats != anchor.amount_sats:
            return False

        confirmations = tx.get("confirmations", 0)
        if confirmations < SPV_CONFIRMATION_DEPTH:
            return False

        return True

    def get_mempool_fee_rate(self) -> Optional[float]:
        """
        Get current mempool fee rate in sat/vbyte.
        Used by credit issuance to determine optimal consolidation windows.
        """
        result = self._call("estimatesmartfee", [6])
        if result and "feerate" in result:
            btc_per_kb = result["feerate"]
            return btc_per_kb * 1e8 / 1000  # convert to sat/vbyte
        return None

    def is_low_fee_window(self, threshold_sat_vbyte: float = 5.0) -> bool:
        """
        Returns True when mempool fees are low enough for
        economical dust consolidation.
        """
        rate = self.get_mempool_fee_rate()
        if rate is None:
            return False
        return rate <= threshold_sat_vbyte
