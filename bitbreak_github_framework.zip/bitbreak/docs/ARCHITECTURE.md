# BitBreak Architecture

Author: Jared Soriente Chang  
Status: Prototype research framework

---

## Overview

BitBreak is a parallel proof-of-work blockchain tracking Bitcoin-denominated credit obligations. It is not a modification of Bitcoin. It runs alongside Bitcoin and depends on Bitcoin for final settlement.

---

## Module Map

```
bitbreak/
├── main.py                     Node entry point
├── include/
│   └── types.py                Core data structures and constants
├── src/
│   ├── chain/
│   │   └── bitcoin_rpc.py      Bitcoin Core RPC client (SPV verification)
│   ├── consensus/
│   │   └── rules.py            Block and transaction validation rules
│   ├── wallet/
│   │   └── credit.py           Dust intake and credit issuance
│   ├── rpc/
│   │   └── server.py           JSON-RPC interface
│   ├── index/
│   │   └── price_index.py      Live price and inflation data
│   └── net/
│       └── peer.py             P2P network layer (stub)
└── tests/
    └── test_core.py            Unit test suite (26 tests)
```

---

## Data Model

### Three-component wallet state

| Component | Description |
|-----------|-------------|
| Confirmed Bitcoin | Spendable on Bitcoin main chain |
| BitBreak Credit | Unsettled Bitcoin obligations |
| Bitcoin Anchors | SPV proofs backing credit |

### Transaction types

| Type | Description |
|------|-------------|
| CREDIT_TRANSFER | Move BBK credit between parties |
| ANCHOR_REGISTRATION | Bind Bitcoin UTXO to BBK credit |
| SETTLEMENT | Destroy BBK credit on Bitcoin settlement |
| DUST_INTAKE | Register dust UTXO as anchor and issue credit |

### Credit tiers

| Dust range (sats) | Credit rate | Reserve | Settlement window |
|-------------------|-------------|---------|-------------------|
| 1 – 546 | 70% | 30% | 90 days |
| 547 – 2,999 | 78% | 22% | 60 days |
| 3,000 – 9,999 | 85% | 15% | 30 days |
| 10,000 – 49,999 | 91% | 9% | 14 days |
| 50,000 – 500,000 | 96% | 4% | 7 days |

---

## Bitcoin Core Integration

BitBreak connects to a running Bitcoin Core node via JSON-RPC to verify SPV proofs. Required Bitcoin Core configuration:

```
# bitcoin.conf
server=1
rpcuser=user
rpcpassword=pass
rpcport=8332
```

BitBreak uses only these RPC calls:
- `getblockcount` — current chain height
- `getblockheader` — anchor verification
- `getrawtransaction` — UTXO validation
- `estimatesmartfee` — consolidation timing

---

## RPC Interface

BitBreak exposes a JSON-RPC interface on port 8333.

```bash
# Get node info
curl -d '{"method":"getnodeinfo","params":[],"id":1}' http://127.0.0.1:8333

# Get current price index
curl -d '{"method":"getindexsummary","params":[],"id":1}' http://127.0.0.1:8333

# Get dust threshold in USD
curl -d '{"method":"getdustthreshold","params":[],"id":1}' http://127.0.0.1:8333

# Get credit tier for 5000 sats
curl -d '{"method":"getcredittierinfo","params":[5000],"id":1}' http://127.0.0.1:8333
```

---

## What This Prototype Does Not Include

This is an honest list of what requires further engineering before production:

- C++ Bitcoin Core integration (this prototype is Python)
- Full merkle proof verification against live Bitcoin headers
- Complete P2P network protocol and peer discovery
- Block serialization format
- Mining implementation
- Persistent chain storage
- Full difficulty retarget algorithm
- Mempool management
- Wallet key management and signing

---

## Contributing

Contributions are welcome. Please open an issue before submitting a pull request for significant changes. All contributions are subject to the MIT license.
