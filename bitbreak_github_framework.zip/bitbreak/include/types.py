"""
bitbreak/include/types.py

Core data structures for the BitBreak protocol.

Author: Jared Soriente Chang
License: MIT
Status: Prototype — not production ready

These structures define the BitBreak data model as specified in the
BitBreak whitepaper. Full implementation requires C++ Bitcoin Core
integration for production deployment.
"""

from dataclasses import dataclass, field
from typing import Optional, List
from enum import Enum
import hashlib
import time


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BITBREAK_VERSION = 1
DUST_THRESHOLD_SATS = 546       # Bitcoin dust threshold in satoshis
MAX_SUPPLY_BBK = 21_000_000     # BitBreak credit supply cap mirrors Bitcoin
CREDIT_HALFLIFE_EPOCHS = 210_000  # Block epochs before credit issuance halves
PROOF_OF_WORK_BITS = 0x1d00ffff  # Initial difficulty target (prototype value)
SPV_CONFIRMATION_DEPTH = 6       # Minimum Bitcoin confirmations for anchor


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class UTXOType(Enum):
    CONFIRMED_BITCOIN = "confirmed_btc"   # Spendable on Bitcoin main chain
    BITBREAK_CREDIT   = "bbk_credit"      # Unsettled Bitcoin obligation
    BITCOIN_ANCHOR    = "btc_anchor"      # Cryptographic proof backing credit


class TransactionType(Enum):
    CREDIT_TRANSFER     = "credit_transfer"    # Move BBK credit between parties
    ANCHOR_REGISTRATION = "anchor_registration" # Bind Bitcoin UTXO to BBK credit
    SETTLEMENT          = "settlement"          # Destroy BBK credit on BTC settlement
    DUST_INTAKE         = "dust_intake"         # Register dust UTXO as anchor


class CreditTier(Enum):
    """
    Credit issuance tier based on dust UTXO size.
    Smaller dust carries higher consolidation reserve.
    """
    MICRO   = "micro"    # 1 – 546 sats:      70% credit, 30% reserve
    SMALL   = "small"    # 547 – 2,999 sats:  78% credit, 22% reserve
    MEDIUM  = "medium"   # 3,000 – 9,999:     85% credit, 15% reserve
    LARGE   = "large"    # 10,000 – 49,999:   91% credit,  9% reserve
    WHALE   = "whale"    # 50,000 – 500,000:  96% credit,  4% reserve


# ---------------------------------------------------------------------------
# Core data structures
# ---------------------------------------------------------------------------

@dataclass
class BitcoinAnchor:
    """
    SPV-verifiable proof linking a Bitcoin UTXO to BitBreak credit.
    Verified using Merkle inclusion proof against Bitcoin block header.
    """
    txid: str                    # Bitcoin transaction ID
    vout: int                    # Output index in the Bitcoin transaction
    amount_sats: int             # Amount in satoshis
    merkle_proof: List[str]      # Merkle branch for SPV verification
    block_header: str            # Bitcoin block header hash
    block_height: int            # Bitcoin block height at anchor registration
    confirmations: int = 0       # Current confirmation depth

    def is_valid_spv(self) -> bool:
        """
        Verify the anchor against Bitcoin SPV proof.
        PROTOTYPE: Full implementation requires Bitcoin Core RPC call
        to verify merkle_proof against block_header.
        """
        # TODO: implement merkle verification against Bitcoin Core
        return (
            len(self.txid) == 64
            and self.confirmations >= SPV_CONFIRMATION_DEPTH
            and self.amount_sats > 0
        )

    def get_credit_tier(self) -> CreditTier:
        s = self.amount_sats
        if s <= 546:        return CreditTier.MICRO
        elif s <= 2999:     return CreditTier.SMALL
        elif s <= 9999:     return CreditTier.MEDIUM
        elif s <= 49999:    return CreditTier.LARGE
        else:               return CreditTier.WHALE


@dataclass
class UTXO:
    """
    BitBreak Unspent Transaction Output.
    Models the three-component wallet state defined in the whitepaper.
    """
    utxo_id: str
    utxo_type: UTXOType
    amount_sats: int              # Denomination in satoshis
    owner_pubkey: str             # Owner's public key
    anchor: Optional[BitcoinAnchor] = None  # Required for BITCOIN_ANCHOR type
    spent: bool = False

    def is_spendable(self) -> bool:
        return not self.spent and self.amount_sats > 0

    def is_dust(self) -> bool:
        return self.amount_sats <= DUST_THRESHOLD_SATS


@dataclass
class BitBreakTransaction:
    """
    A BitBreak transaction consuming existing UTXOs and producing new ones.
    Total output value may not exceed total input value (conservation rule).
    """
    tx_id: str
    tx_type: TransactionType
    inputs: List[str]             # List of UTXO IDs consumed
    outputs: List[UTXO]           # New UTXOs produced
    anchor: Optional[BitcoinAnchor] = None  # Required for anchor_registration
    timestamp: int = field(default_factory=lambda: int(time.time()))
    signature: str = ""

    def validate_conservation(self, input_utxos: List[UTXO]) -> bool:
        """
        Verify output value does not exceed input value.
        Core conservation rule preventing credit inflation.
        """
        total_in  = sum(u.amount_sats for u in input_utxos)
        total_out = sum(u.amount_sats for u in self.outputs)
        return total_out <= total_in

    def compute_txid(self) -> str:
        """
        Compute transaction ID as SHA256d of serialized transaction data.
        PROTOTYPE: Full serialization format TBD in C++ implementation.
        """
        raw = f"{self.tx_type.value}:{self.inputs}:{self.timestamp}"
        h = hashlib.sha256(hashlib.sha256(raw.encode()).digest()).hexdigest()
        return h


@dataclass
class BitBreakBlock:
    """
    A block in the BitBreak proof-of-work chain.
    Includes a Bitcoin anchor committing to Bitcoin state at this height.
    """
    height: int
    prev_hash: str
    merkle_root: str              # Merkle root of transactions in this block
    bitcoin_anchor_hash: str      # Hash of committed Bitcoin block header
    nonce: int
    bits: int                     # Difficulty target
    timestamp: int = field(default_factory=lambda: int(time.time()))
    transactions: List[BitBreakTransaction] = field(default_factory=list)
    block_hash: str = ""

    def compute_hash(self) -> str:
        """
        SHA256d of block header fields.
        PROTOTYPE: Production requires optimized C++ implementation.
        """
        header = (
            f"{self.height}{self.prev_hash}{self.merkle_root}"
            f"{self.bitcoin_anchor_hash}{self.nonce}{self.bits}{self.timestamp}"
        )
        return hashlib.sha256(
            hashlib.sha256(header.encode()).digest()
        ).hexdigest()

    def meets_difficulty(self) -> bool:
        """
        Check if block hash meets the proof-of-work difficulty target.
        PROTOTYPE: Full difficulty calculation matches Bitcoin's algorithm.
        """
        target_prefix = "0" * (self.bits >> 24)
        return self.block_hash.startswith(target_prefix)


@dataclass
class WalletState:
    """
    Three-component wallet state per whitepaper specification.
    """
    owner_pubkey: str
    confirmed_bitcoin: List[UTXO] = field(default_factory=list)
    bitbreak_credit: List[UTXO]   = field(default_factory=list)
    bitcoin_anchors: List[UTXO]   = field(default_factory=list)

    def total_confirmed_btc(self) -> int:
        return sum(u.amount_sats for u in self.confirmed_bitcoin if u.is_spendable())

    def total_bbk_credit(self) -> int:
        return sum(u.amount_sats for u in self.bitbreak_credit if u.is_spendable())

    def dust_utxos(self) -> List[UTXO]:
        return [u for u in self.confirmed_bitcoin if u.is_dust() and u.is_spendable()]
